# Discourse Lohnrechner

Adds an option to generate a Lohnrechner Token and redirect the User to the Lohnrecher Page
